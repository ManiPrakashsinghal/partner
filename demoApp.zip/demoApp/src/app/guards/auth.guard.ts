import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { AppService } from '../app.service';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate   {
    constructor(public auth: AppService) { }
 
  canActivate(): boolean {
      return this.auth.isAuthenticated();
    }
}
