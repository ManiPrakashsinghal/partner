import { Component } from '@angular/core';
import { AppService } from '../app.service';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-login',
  templateUrl: 'login.page.html',
  styleUrls: ['login.page.scss'],
})
export class LoginPage {

  constructor(private authService: AppService, private plt: Platform) {

  }

  login() {
    this.authService.login();
  }

}
