import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../app.service';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  constructor(
    private router: Router,
    private authService: AppService,
    private plt: Platform,
     
  ) {

    // this.plt.ready().then(() => {
    //   plt.backButton.subscribe(async () => {
    //     if (this.authService.alertShown == false) {
    //       this.authService.presentConfirm();
    //     }
    //   });
    // });

  }

  
  logout() {
    this.authService.logout();
  }
  


}
