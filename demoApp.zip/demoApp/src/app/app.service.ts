import { Platform, AlertController, IonRouterOutlet } from '@ionic/angular';
import { Injectable, ViewChildren, QueryList } from '@angular/core';
import { Storage } from '@ionic/storage';
import { BehaviorSubject } from 'rxjs';

const TOKEN_KEY = 'auth-token';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  authenticationState = new BehaviorSubject(false);
  public alertShown: boolean = false;

  @ViewChildren(IonRouterOutlet) routerOutlets: QueryList<IonRouterOutlet>;
  constructor(
    private storage: Storage,
    private plt: Platform,
    public alertCtrl: AlertController
     
    ) {
    this.plt.ready().then(() => {
      this.checkToken();
      // plt.backButton.subscribe(async () => {
      //   console.log("event fired");
      //   this.routerOutlets.forEach((outlet: IonRouterOutlet) => {

      //     if (outlet && outlet.canGoBack()) {
      //       outlet.pop();

      //     }else if (this.alertShown == false) {

      //       this.presentConfirm();
      //     }
      
      //   });
      // })
    });
  }

  checkToken() {
    this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        this.authenticationState.next(true);
      }
    })
  }
  login() {
    return this.storage.set(TOKEN_KEY, 'Bearer 1234567').then(() => {
      this.authenticationState.next(true);
    });
  }

  logout() {
    return this.storage.remove(TOKEN_KEY).then(() => {
      this.authenticationState.next(false);
    });
  }

  isAuthenticated() {
    return this.authenticationState.value;
  }

  // presentConfirm() {
  //   this.alertCtrl.create({
  //     header: 'Confirm Exit',
  //     message: 'Do you want to Exit?',
  //     buttons: [
  //       {
  //         text: 'Cancel',
  //         role: 'cancel',
  //         handler: () => {
  //           console.log('Cancel clicked');
  //           this.alertShown = false;
  //         }
  //       },
  //       {
  //         text: 'Yes',
  //         handler: () => {
  //           console.log('Yes clicked');
  //           navigator['app'].exitApp();
  //         }
  //       }
  //     ]
  //   }).then(alert => {
  //     alert.present()
  //     this.alertShown = true;
  //   });
  // }
}

