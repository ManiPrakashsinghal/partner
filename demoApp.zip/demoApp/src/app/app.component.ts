import { Component, QueryList, ViewChildren } from '@angular/core';

import { Router } from '@angular/router';
import { AppService } from './app.service';
import { Toast } from '@ionic-native/toast/ngx';
import { Platform, IonRouterOutlet, ModalController, MenuController, ActionSheetController, PopoverController, ToastController, NavController, AlertController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {

  lastTimeBackPress = 0;
  timePeriodToExit = 2000;
  public alertShown: boolean = false;

  @ViewChildren(IonRouterOutlet) routerOutlets: QueryList<IonRouterOutlet>;
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private authenticationService: AppService,
    public modalCtrl: ModalController,
    private menu: MenuController,
    private actionSheetCtrl: ActionSheetController,
    private popoverCtrl: PopoverController,
    private router: Router,
    private toast: Toast,
    private nav: NavController,
    public alertCtrl: AlertController
  ) {
    this.initializeApp();
    //this.backButtonEvent();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      
      this.splashScreen.hide();

      this.authenticationService.authenticationState.subscribe(state => {
        if (state) {
          this.nav.navigateRoot(['home', 'tabs', 'tab1']);
        } else {
          this.router.navigate(['login']);
        }
      });


      this.platform.backButton.subscribe(async () => {
        console.log("event fired");
        this.routerOutlets.forEach((outlet: IonRouterOutlet) => {

          if (outlet && outlet.canGoBack()) {
            outlet.pop();

          } else if (this.alertShown == false) {

            this.presentConfirm();
          }

        });
      })


    });
  }


  presentConfirm() {
    this.alertCtrl.create({
      header: 'Confirm Exit',
      message: 'Do you want to Exit?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
            this.alertShown = false;
          }
        },
        {
          text: 'Yes',
          handler: () => {
            console.log('Yes clicked');
            navigator['app'].exitApp();
          }
        }
      ]
    }).then(alert => {
      alert.present()
      this.alertShown = true;
    });
  }
//   backButtonEvent() {
//     this.platform.backButton.subscribe(async () => {
//       console.log("event fired");
//       // close action sheet

//       this.routerOutlets.forEach((outlet: IonRouterOutlet) => {
//         if (outlet && outlet.canGoBack()) {
//           outlet.pop();

//         } else if (this.router.url === '/login') {
//           if (new Date().getTime() - this.lastTimeBackPress < this.timePeriodToExit) {
//              // this.platform.exitApp(); // Exit from app
//             navigator['app'].exitApp(); // work for ionic 4

//           } else {
//             this.toast.show(
//             `Press back again to exit App.`,
//             '2000',
//             'center')
//             .subscribe(toast => {
//                console.log(JSON.stringify(toast));
//             });
//           this.lastTimeBackPress = new Date().getTime();
//           }
//         } else if (this.router.url === '/home') {
//           if (new Date().getTime() - this.lastTimeBackPress < this.timePeriodToExit) {
//             // this.platform.exitApp(); // Exit from app
//             navigator['app'].exitApp(); // work for ionic 4

//           } else {
//             this.toast.show(
//               `Press back again to exit App.`,
//               '2000',
//               'center')
//               .subscribe(toast => {
//                 console.log(JSON.stringify(toast));
//               });
//             this.lastTimeBackPress = new Date().getTime();
//           }
//         } else if (this.router.url === '/home/tabs/tab1') {
//           if (new Date().getTime() - this.lastTimeBackPress < this.timePeriodToExit) {
//             // this.platform.exitApp(); // Exit from app
//             navigator['app'].exitApp(); // work for ionic 4

//           } else {
//             this.toast.show(
//               `Press back again to exit App.`,
//               '2000',
//               'center')
//               .subscribe(toast => {
//                 console.log(JSON.stringify(toast));
//               });
//             this.lastTimeBackPress = new Date().getTime();
//           }
//         }
//       });
//     })
// }

}
