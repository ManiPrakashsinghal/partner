import { Component, ViewChildren, QueryList } from '@angular/core';

import { Platform, IonRouterOutlet, AlertController, NavController } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { CommonServiceService } from './common-service.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent {
  public appPages = [
    {
      title: 'Home',
      url: '/home',
      icon: 'home'
    },
	{
      title: 'Add Client',
      url: '/add-client',
      icon: 'person-add'
    },
    {
      title: 'Today Work',
      url: '/today-work',
      icon: 'document'
    }
    ,
    {
      title: 'Daily Report',
      url: '/daily-work',
      icon: 'paper'
    }
  ];

public alertShown: boolean = false;
@ViewChildren(IonRouterOutlet) routerOutlets: QueryList<IonRouterOutlet>;


  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    public alertCtrl: AlertController,
    private authenticationService : CommonServiceService,
    private nav: NavController,
    private router: Router
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();

      this.authenticationService.authenticationState.subscribe(state => {
        if (state) {
          this.nav.navigateRoot(['home']);
        } else {
          this.nav.navigateRoot(['login']);
        }
      });

      this.platform.backButton.subscribe(async () => {
        console.log("event fired");
        this.routerOutlets.forEach((outlet: IonRouterOutlet) => {

          if (outlet && outlet.canGoBack()) {
            outlet.pop();

          } else if (this.alertShown == false) {

            this.presentConfirm();
          }

        });
      })


    });

    
  }


  presentConfirm() {
    this.alertCtrl.create({
      header: 'Confirm Exit',
      message: 'Do you want to Exit?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
            this.alertShown = false;
          }
        },
        {
          text: 'Yes',
          handler: () => {
            console.log('Yes clicked');
            navigator['app'].exitApp();
          }
        }
      ]
    }).then(alert => {
      alert.present()
      this.alertShown = true;
    });
  }

}
