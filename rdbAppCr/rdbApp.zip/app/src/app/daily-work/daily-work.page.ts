import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { CommonServiceService } from '../common-service.service';

@Component({
  selector: 'app-daily-work',
  templateUrl: './daily-work.page.html',
  styleUrls: ['./daily-work.page.scss'],
})
export class DailyWorkPage implements OnInit {

  report:any;
  constructor(private datePipe: DatePipe,private route: ActivatedRoute, private commonService: CommonServiceService) { }


  ngOnInit() {
  }

  onSubmit(event){


    var toDate =this.datePipe.transform(new Date(), 'yyyy-MM-dd');
   
    let obj = {
      "report" : this.report,
      "empId"  : this.commonService.getClientId(),
      "todayDate" : toDate
    };
    this.commonService.insertDailyReport(obj)
        .subscribe(
          paymentObjArr => {
           if(paymentObjArr){
             this.report = "";
           }
          });
  }

}
