import { Component, OnInit } from '@angular/core';
import { CommonServiceService } from '../common-service.service';
import { AlertController, LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { CallNumber } from '@ionic-native/call-number/ngx';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {
  clientArray: any;
  private subscriptionObj: Subscription;
  public searchText:any;

  allData = []; //Store all data from provider
  

  constructor(private router: Router,
              private loadingCtrl: LoadingController,
              private alertCtrl: AlertController,
              private commonService: CommonServiceService,
              private callNumberObj: CallNumber
    ) { }

    ngOnInit() {
   
    }

    ionViewWillEnter() {
      this.commonService.getAdminClient().subscribe( planDetail => {
        console.log('planDetail ' + JSON.stringify(planDetail));
        this.clientArray = planDetail;
		this.allData = planDetail;
      });
    }


    callNumber(no){
      this.callNumberObj.callNumber(no, true)
      .then(res => console.log('Launched dialer!', res))
      .catch(err => console.log('Error launching dialer', err));
    }

    logout() {
      this.commonService.logout();
    }

    initializeItems(){ 
      this.clientArray = this.allData ; 
  }

    public SearchList = (ev) => {

      // Reset items back to all of the items
    this.initializeItems();

    // set val to the value of the searchbar
    const text = ev.target.value;

		this.clientArray = this.allData.filter((obj) => {
		  return (obj.name.toLowerCase().indexOf(text.toLowerCase()) > -1) || (obj.mobile.toLowerCase().indexOf(text.toLowerCase()) > -1);
		});
    }

}
 