import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { take, map, tap, delay, switchMap } from 'rxjs/operators';
import { AlertController,Platform } from '@ionic/angular';
import { Storage } from '@ionic/storage';

const TOKEN_KEY = 'auth-token';

@Injectable({
  providedIn: 'root'
})

export class CommonServiceService {

  authenticationState = new BehaviorSubject(false);
  private userBehaviourObj = new BehaviorSubject<object>([]);
  fetchData: any;
  private clientId = null;

  constructor(private http: HttpClient, private alertCtrl: AlertController,
    private plt: Platform,private storage: Storage) {
      this.plt.ready().then(() => {
        this.checkToken();
      });
    }

  login() {
    return this.clientId;
  }


  setClientId(id){
    this.clientId = id;
  }

  getClientId(){
      return this.clientId;
  }

  get getLoginUserDetail() {
    return this.userBehaviourObj.asObservable();
  }


  OnloginUserService(userMobileNmber: string , userPassword: string) {
    console.log(`userMobileNmber :: ${userMobileNmber} userPassword :: ${userPassword} `);
     // tslint:disable-next-line: max-line-length
    return this.http.post(`http://13.234.233.214/employeeLogin`, {
      empEmail : userMobileNmber,
      empPassword : userPassword
    }).pipe(
      map(resData => {
        console.log(resData);
        if(resData["status"] == "1"){
          let id:any =  resData["result"][0]["id"];
          this.setClientId(id);
          this.setLogin();
          return true;
        }else{
           let msg:any = resData["message"];
            this.showMessage(msg);
            return false;
        }
   }));
  }

  getAdminClient() {
    return this.http.post<{}>(`http://13.234.233.214/getAdminClient`, {
      empId : 1
    }).pipe(
      map(resData => {
        console.log(resData);
        if(resData["status"] == "1"){
          return resData['result'];
        }else{
           let msg:any = resData["message"];
            this.showMessage(msg);
            return [];
        }
   })
    );
  }

  getAllClientQuery(clientIdValue: string) {
    return this.http.post<{}>(`http://13.234.233.214/getAllClientQuery`, {
      clientId : clientIdValue
    }).pipe(
      map(resData => {
        console.log(resData);
        if(resData["status"] == "1"){
          return resData['result'];
        }else{
           let msg:any = resData["message"];
            this.showMessage(msg);
            return [];
        }
       })
    );
  }


  getAllTodatWork(obj:Object) {
    return this.http.post<{}>(`http://13.234.233.214/getTodayDetail`,obj).pipe(
      map(resData => {
        console.log(resData);
        if(resData["status"] == "1"){
          return resData['result'];
        }else{
           let msg:any = resData["message"];
            this.showMessage(msg);
            return [];
        }
   })
    );
  }


  insertClientQuery(clientIdValue: Object) {
    return this.http.post<{}>(`http://13.234.233.214/insertClientQuery`, clientIdValue).pipe(
      map(resData => {
        console.log(resData);
        if(resData["status"] == "1"){
          let msg:any = resData["message"];
          this.showMessage(msg);
          return true;
        }else{
           let msg:any = resData["message"];
            this.showMessage(msg);
            return false;
        }
      
       })
      );
  }


  insertDailyReport(clientIdValue: Object) {
    return this.http.post<{}>(`http://13.234.233.214/insertDailyReport`, clientIdValue).pipe(
      map(resData => {
        console.log(resData);
        if(resData["status"] == "1"){
          let msg:any = resData["message"];
          this.showMessage(msg);
          return true;
        }else{
           let msg:any = resData["message"];
            this.showMessage(msg);
            return false;
        }
      
       })
      );
  }
  
  insertAdminClient(clientIdValue: Object) {
    return this.http.post<{}>(`http://13.234.233.214/insertAdminClient`, clientIdValue).pipe(
      map(resData => {
        console.log(resData);
        if(resData["status"] == "1"){
          let msg:any = resData["message"];
          this.showMessage(msg);
          return true;
        }else{
           let msg:any = resData["message"];
            this.showMessage(msg);
            return false;
        }
      
       })
      );
  }


  

  showMessage(msg){
    this.alertCtrl
    .create({
      header: '',
      message: msg,
      buttons: [
        {
          text: 'Okay',
          handler: () => {
           //this.router.navigate(['/admin-dashboard']);
          }
        }
      ]
    })
    .then(alertEl => {
      alertEl.present();
    });
  }

  checkToken() {
    this.storage.get(TOKEN_KEY).then(res => {
      if (res) {
        this.authenticationState.next(true);
        this.setClientId(res);
      }
    })
  }

  setLogin() {
    return this.storage.set(TOKEN_KEY,this.clientId).then(() => {
      this.authenticationState.next(true);
    });
  }

  logout() {
    return this.storage.remove(TOKEN_KEY).then(() => {
      this.authenticationState.next(false);
    });
  }

  isAuthenticated() {
    return this.authenticationState.value;
  }

}
