import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllQueryPage } from './all-query.page';

describe('AllQueryPage', () => {
  let component: AllQueryPage;
  let fixture: ComponentFixture<AllQueryPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllQueryPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllQueryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
