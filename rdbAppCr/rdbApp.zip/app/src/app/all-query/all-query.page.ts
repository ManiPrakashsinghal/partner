import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonServiceService } from '../common-service.service';

@Component({
  selector: 'app-all-query',
  templateUrl: './all-query.page.html',
  styleUrls: ['./all-query.page.scss'],
})
export class AllQueryPage implements OnInit {
  
  clientId: any;
  queryArray:any;
  constructor(private route: ActivatedRoute,
              private commonService: CommonServiceService
              ) { }

  ngOnInit() {
    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('clientId')) {
       console.log('Not Found..');
       return;
      }
      console.log('Not Found..'+ paramMap.get('clientId'));
      this.clientId = paramMap.get('clientId');
      this.commonService.getAllClientQuery(paramMap.get('clientId'))
        .subscribe(
          paymentObjArr => {
            console.log(paymentObjArr);
            this.queryArray = paymentObjArr;
          });
    });
  }

}
