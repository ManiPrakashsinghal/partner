import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { CommonServiceService } from '../common-service.service';


@Component({
  selector: 'app-add-client',
  templateUrl: './add-client.page.html',
  styleUrls: ['./add-client.page.scss'],
})
export class AddClientPage implements OnInit {

   name:any;
   mobNO:any;
   remark:any;
  constructor(private datePipe: DatePipe,private route: ActivatedRoute, private commonService: CommonServiceService) { }

  ngOnInit() {
  }
  
   onSubmit(event){


    var toDate =this.datePipe.transform(new Date(), 'yyyy-MM-dd');
   
    let obj = {
      "name" : this.name,
      "forwardEmpId"  : this.commonService.getClientId(),
      "todayDate" : toDate,
	  "mobile" : this.mobNO.toString(),
	  "remark" : this.remark
    };
    this.commonService.insertAdminClient(obj)
        .subscribe(
          paymentObjArr => {
           if(paymentObjArr){
             this.name = "";
			 this.mobNO = "";
			 this.remark = "";
           }
          });
  }

}
