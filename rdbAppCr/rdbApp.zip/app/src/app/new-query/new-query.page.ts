import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { CommonServiceService } from '../common-service.service';

@Component({
  selector: 'app-new-query',
  templateUrl: './new-query.page.html',
  styleUrls: ['./new-query.page.scss'],
})

export class NewQueryPage implements OnInit {
 
  res:any = "";
  des:any = "";
  userRegModel:any;
  clientId:any;

  constructor(private datePipe: DatePipe,private route: ActivatedRoute, private commonService: CommonServiceService) { }

  ngOnInit() {

    
  }

  onSubmit(eve){

    this.route.paramMap.subscribe(paramMap => {
      if (!paramMap.has('clientId')) {
       console.log('Not Found..');
       this.clientId = 0;
      }else{
          this.clientId =paramMap.get('clientId');
      }
    });

    var toDate =this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    var dateNext =this.datePipe.transform(this.userRegModel, 'yyyy-MM-dd');
 
    let obj = {
      "nextCall" : dateNext,
      "description" : this.des,
      "response" : this.res,
      "clientId" : this.clientId,
      "todayDate" : toDate
    };

    this.commonService.insertClientQuery(obj)
        .subscribe(
          paymentObjArr => {
           if(paymentObjArr){
             this.res = "";
             this.des="";
             this.userRegModel = "";
           }
          });
  }

}
