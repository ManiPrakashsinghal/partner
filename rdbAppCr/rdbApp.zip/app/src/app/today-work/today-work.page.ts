import { Component, OnInit } from '@angular/core';
import { CommonServiceService } from '../common-service.service';
import { AlertController, LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { DatePipe } from '@angular/common';
import { CallNumber } from '@ionic-native/call-number/ngx';


@Component({
  selector: 'app-today-work',
  templateUrl: './today-work.page.html',
  styleUrls: ['./today-work.page.scss'],
})
export class TodayWorkPage implements OnInit {

  clientArray: any;

  constructor(private router: Router,
              private loadingCtrl: LoadingController,
              private alertCtrl: AlertController,
              private commonService: CommonServiceService,
              private datePipe: DatePipe,
              private callNumberObj: CallNumber
    ) { }

    ngOnInit() {
   
    }

    ionViewWillEnter() {
      var toDate =this.datePipe.transform(new Date(), 'yyyy-MM-dd');
      let obj = {
        "todayDate" : toDate,
        "empId" : this.commonService.getClientId()
      }
      this.commonService.getAllTodatWork(obj).subscribe( planDetail => {
        console.log('planDetail ' + JSON.stringify(planDetail));
        this.clientArray = planDetail;
      });
    }

    callNumber(no){
      this.callNumberObj.callNumber(no, true)
      .then(res => console.log('Launched dialer!', res))
      .catch(err => console.log('Error launching dialer', err));
    }

}
