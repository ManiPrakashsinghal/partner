import { Component, OnInit,OnDestroy, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators , FormBuilder } from '@angular/forms';
import { LoadingController, AlertController, MenuController } from '@ionic/angular';

import { Subscription } from 'rxjs';
import { CommonServiceService } from '../common-service.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit,OnDestroy  {

  

  form: FormGroup;
  userFirstName: any;
  userMobile: any;
  private subscriptionObj: Subscription;

  constructor(private router: Router,
              private formBuilder: FormBuilder,
              private loadingCtrl: LoadingController,
              private alertCtrl: AlertController,
              private commonService: CommonServiceService,
              private menu: MenuController
              ) { 
                this.menu.enable(false);
              }

  ngOnInit() {
    this.form = this.formBuilder.group({
      mobileNumber: ['', [
        Validators.required
      ]],
      password: ['', [
        Validators.required
      ]],
    });
  }

  ngOnDestroy(): void {
    this.menu.enable(true);
  }

   get mobileNumber() {
      return this.form.get('mobileNumber');
   }
   get password() {
    return this.form.get('password');
   }

  onLogin() {

      console.log(this.form.get('mobileNumber'));
      this.userMobile = this.form.value.mobileNumber;
      const userPassword = this.form.value.password;

      this.loadingCtrl
          .create({
            message: 'Login please wait...'
          })
          .then(loadingEl => {
            loadingEl.present();
            this.commonService.OnloginUserService(this.userMobile, userPassword).subscribe( retrnStatus => {
                 loadingEl.dismiss();
                 if(retrnStatus){
                       this.router.navigate(['/home'], { replaceUrl: true });
                 }
            },
            error => {
              loadingEl.dismiss();
              this.alertCtrl
                .create({
                  header: 'An error occurred!',
                  message: 'Please Check Your Network Connection!',
                  buttons: [
                    {
                      text: 'Okay',
                      handler: () => {
                       //this.router.navigate(['/admin-dashboard']);
                      }
                    }
                  ]
                })
                .then(alertEl => {
                  alertEl.present();
                });
            }
    );

          });
  }
}
