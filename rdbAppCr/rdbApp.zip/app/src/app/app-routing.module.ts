import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  { path: 'login', loadChildren: './login/login.module#LoginPageModule' },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then(m => m.HomePageModule)
  },
  {
    path: 'list',
    loadChildren: () => import('./list/list.module').then(m => m.ListPageModule)
  },
  { path: 'all-query/:clientId', loadChildren: './all-query/all-query.module#AllQueryPageModule' },
  { path: 'new-query/:clientId', loadChildren: './new-query/new-query.module#NewQueryPageModule' },
  { path: 'today-work', loadChildren: './today-work/today-work.module#TodayWorkPageModule' },
  { path: 'daily-work', loadChildren: './daily-work/daily-work.module#DailyWorkPageModule' },
  { path: 'add-client', loadChildren: './add-client/add-client.module#AddClientPageModule' },

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
