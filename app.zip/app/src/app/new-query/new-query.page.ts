import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-query',
  templateUrl: './new-query.page.html',
  styleUrls: ['./new-query.page.scss'],
})
export class NewQueryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
