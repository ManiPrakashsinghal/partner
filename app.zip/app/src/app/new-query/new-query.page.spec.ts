import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewQueryPage } from './new-query.page';

describe('NewQueryPage', () => {
  let component: NewQueryPage;
  let fixture: ComponentFixture<NewQueryPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewQueryPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewQueryPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
