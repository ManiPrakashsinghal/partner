import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-query',
  templateUrl: './all-query.page.html',
  styleUrls: ['./all-query.page.scss'],
})
export class AllQueryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
